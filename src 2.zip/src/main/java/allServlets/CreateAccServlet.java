package allServlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class CreateAccServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch(ClassNotFoundException e){
            System.out.println("could not connect"+ e.getMessage());
            // e.printStackTrace();
        }
        // Drivers has been loaded

        try{
        	PrintWriter out=response.getWriter();
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javaExpl", "root", "system");
//            Statement statement = con.createStatement( );
            
            String n1= request.getParameter("c_id");
            String n2= request.getParameter("c_name");
            String n3= request.getParameter("acc_no");
            String n4= request.getParameter("br_name");
            String n5= request.getParameter("ph_no");
            String n6= request.getParameter("password");
            
            PreparedStatement ps= con.prepareStatement("insert into customers values(?,?,?,?,?,0,?)");
            ps.setString(1, n1);
            ps.setString(2, n2);
            ps.setString(3, n3);
            ps.setString(4, n4);
            ps.setString(5, n5);
            ps.setString(6, n6);
            ps.executeUpdate();
            
//            out.println("Execution Successful.");
            
            ResultSet rs = ps.executeQuery("select * from customers where c_name='" + n2 +"'");
            
            if(rs.next()) {
            	RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
            	rd.forward(request, response);
            	
//            	out.println("<font color=red size=18>Logined!! <br>"); 
//            	out.println("<a href=login.jsp> try AGAIN </a>");
            }
            else {
//            	response.setContentType("text/html");   
//            	PrintWriter out = response.getWriter();
            	out.println("<font color=red size=18>Login Failed!! <br>"); 
            	out.println("<a href=custLogin.jsp>Please Try Again.</a>");
            	
            }
        }
        catch(SQLException e){
            System.out.println("execution failed"+ e.getMessage());
        }
	}
}
