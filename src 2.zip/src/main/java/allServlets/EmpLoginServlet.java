package allServlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 * Servlet implementation class EmpLoginServlet
 */
public class EmpLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch(ClassNotFoundException e){
            System.out.println("could not connect"+ e.getMessage());
            // e.printStackTrace();
        }
        // Drivers has been loaded

        try{
        	PrintWriter out=response.getWriter();
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javaExpl", "root", "system");
//            Statement statement = con.createStatement( );
            
            String n= request.getParameter("username");
            String p= request.getParameter("password");
            
            PreparedStatement ps= con.prepareStatement("select username from users where username=? and password=?");
            ps.setString(1, n);
            ps.setString(2, p);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()) {
            	RequestDispatcher rd = request.getRequestDispatcher("empDetails.jsp");
            	rd.forward(request, response);
            	
//            	out.println("<font color=red size=18>Logined!! <br>"); 
//            	out.println("<a href=login.jsp> try AGAIN </a>");
            }
            else {
//            	response.setContentType("text/html");   
//            	PrintWriter out = response.getWriter();
            	out.println("<font color=red size=18>Login Failed!! <br>"); 
            	out.println("<a href=empLogin.jsp>Please Try Again.</a>");
            }
        }
        catch(SQLException e){
            System.out.println("Roye Roye "+ e.getMessage());
        }
		
	}

}
